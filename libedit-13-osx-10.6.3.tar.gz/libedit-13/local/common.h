/* Automatically generated file, do not edit */
#ifndef _h_common_c
#define _h_common_c
protected el_action_t	ed_end_of_file (EditLine *, int);
protected el_action_t	ed_insert (EditLine *, int);
protected el_action_t	ed_delete_prev_word (EditLine *, int);
protected el_action_t	ed_delete_next_char (EditLine *, int);
protected el_action_t	ed_kill_line (EditLine *, int);
protected el_action_t	ed_move_to_end (EditLine *, int);
protected el_action_t	ed_move_to_beg (EditLine *, int);
protected el_action_t	ed_transpose_chars (EditLine *, int);
protected el_action_t	ed_next_char (EditLine *, int);
protected el_action_t	ed_prev_word (EditLine *, int);
protected el_action_t	ed_prev_char (EditLine *, int);
protected el_action_t	ed_quoted_insert (EditLine *, int);
protected el_action_t	ed_digit (EditLine *, int);
protected el_action_t	ed_argument_digit (EditLine *, int);
protected el_action_t	ed_unassigned (EditLine *, int);
protected el_action_t	ed_tty_sigint (EditLine *, int);
protected el_action_t	ed_tty_dsusp (EditLine *, int);
protected el_action_t	ed_tty_flush_output (EditLine *, int);
protected el_action_t	ed_tty_sigquit (EditLine *, int);
protected el_action_t	ed_tty_sigtstp (EditLine *, int);
protected el_action_t	ed_tty_stop_output (EditLine *, int);
protected el_action_t	ed_tty_start_output (EditLine *, int);
protected el_action_t	ed_newline (EditLine *, int);
protected el_action_t	ed_delete_prev_char (EditLine *, int);
protected el_action_t	ed_clear_screen (EditLine *, int);
protected el_action_t	ed_redisplay (EditLine *, int);
protected el_action_t	ed_start_over (EditLine *, int);
protected el_action_t	ed_sequence_lead_in (EditLine *, int);
protected el_action_t	ed_prev_history (EditLine *, int);
protected el_action_t	ed_next_history (EditLine *, int);
protected el_action_t	ed_search_prev_history (EditLine *, int);
protected el_action_t	ed_search_next_history (EditLine *, int);
protected el_action_t	ed_prev_line (EditLine *, int);
protected el_action_t	ed_next_line (EditLine *, int);
protected el_action_t	ed_command (EditLine *, int);
#endif /* _h_common_c */

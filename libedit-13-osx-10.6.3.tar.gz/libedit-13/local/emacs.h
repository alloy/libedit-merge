/* Automatically generated file, do not edit */
#ifndef _h_emacs_c
#define _h_emacs_c
protected el_action_t	em_delete_or_list (EditLine *, int);
protected el_action_t	em_delete_next_word (EditLine *, int);
protected el_action_t	em_yank (EditLine *, int);
protected el_action_t	em_kill_line (EditLine *, int);
protected el_action_t	em_kill_region (EditLine *, int);
protected el_action_t	em_copy_region (EditLine *, int);
protected el_action_t	em_gosmacs_transpose (EditLine *, int);
protected el_action_t	em_next_word (EditLine *, int);
protected el_action_t	em_upper_case (EditLine *, int);
protected el_action_t	em_capitol_case (EditLine *, int);
protected el_action_t	em_lower_case (EditLine *, int);
protected el_action_t	em_set_mark (EditLine *, int);
protected el_action_t	em_exchange_mark (EditLine *, int);
protected el_action_t	em_universal_argument (EditLine *, int);
protected el_action_t	em_meta_next (EditLine *, int);
protected el_action_t	em_toggle_overwrite (EditLine *, int);
protected el_action_t	em_copy_prev_word (EditLine *, int);
protected el_action_t	em_inc_search_next (EditLine *, int);
protected el_action_t	em_inc_search_prev (EditLine *, int);
protected el_action_t	em_delete_prev_char (EditLine *, int);
#endif /* _h_emacs_c */

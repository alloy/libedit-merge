/* Automatically generated file, do not edit */
#ifndef _h_help_c
#define _h_help_c
protected const el_bindings_t *help__get(void);
#endif /* _h_help_c */
